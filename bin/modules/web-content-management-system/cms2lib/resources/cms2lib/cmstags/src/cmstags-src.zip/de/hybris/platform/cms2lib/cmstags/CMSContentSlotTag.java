/*
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.cms2lib.cmstags;

import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.cms2.model.contents.components.SimpleCMSComponentModel;
import de.hybris.platform.cms2.model.contents.contentslot.ContentSlotModel;
import de.hybris.platform.cms2.model.preview.CMSPreviewTicketModel;
import de.hybris.platform.cms2.servicelayer.services.CMSContentSlotService;
import de.hybris.platform.cms2.servicelayer.services.CMSPreviewService;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


public class CMSContentSlotTag extends BodyTagSupport
{
	private static final long serialVersionUID = -2741851653451895432L;

	protected static final Logger LOG = Logger.getLogger(CMSContentSlotTag.class.getName());

	private ContentSlotModel contentSlot;
	private List<SimpleCMSComponentModel> components;
	private SimpleCMSComponentModel item;
	private String var;
	private int index;
	private int size;
	private int scope = PageContext.REQUEST_SCOPE;
	private String uid;
	private String position;

	/*
	 * Suppress sonar warning (squid:S1699 | Constructors should only call non-overridable methods) : Legacy code
	 */
	@SuppressWarnings("squid:S1699")
	public CMSContentSlotTag()
	{
		super();
		init();
	}

	@Override
	public void release()
	{
		super.release();
		init();
	}

	protected void init()
	{
		index = 0;
		size = 0;
		var = null;
		components = null;
		item = null;
		scope = PageContext.REQUEST_SCOPE;
		uid = null;
		position = null;
	}

	protected void prepare()
	{
		components = new ArrayList<SimpleCMSComponentModel>();
		final WebApplicationContext appContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(pageContext.getServletContext());
		final CMSContentSlotService contentSlotService = (CMSContentSlotService) appContext.getBean("cmsContentSlotService");
		if (!StringUtils.isEmpty(uid))
		{
			try
			{
				contentSlot = contentSlotService.getContentSlotForId(uid);
			}
			catch (final UnknownIdentifierException e)
			{
				LOG.warn("Error processing tag: " + e.getMessage());
			}
		}
		if (contentSlot != null)
		{
			if (!StringUtils.isEmpty(position))
			{
				contentSlot.setCurrentPosition(position);
			}
			components.addAll(contentSlotService.getSimpleCMSComponents(contentSlot, isPreviewEnabled(),
					(HttpServletRequest) pageContext.getRequest()));

		}
		size = components.size();
	}

	protected boolean isPreviewEnabled()
	{
		boolean previewEnabled = false;

		final String ticketId = pageContext.getRequest().getParameter(CMSFilter.PREVIEW_TICKET_ID_PARAM);
		if (StringUtils.isNotBlank(ticketId))
		{
			final WebApplicationContext appContext = WebApplicationContextUtils
					.getRequiredWebApplicationContext(pageContext.getServletContext());
			final CMSPreviewService service = (CMSPreviewService) appContext.getBean("cmsPreviewService");
			final CMSPreviewTicketModel previewTicket = service.getPreviewTicket(ticketId);
			if (previewTicket == null)
			{
				LOG.warn("No preview ticket found with id '" + ticketId + "'.");
			}
			else
			{
				previewEnabled = Boolean.FALSE.equals(previewTicket.getPreviewData().getEditMode());
			}
		}
		else if (LOG.isDebugEnabled())
		{
			LOG.debug("Could not determine preview edit status. Reason: No preview ticket ID supplied.");
		}
		return previewEnabled;
	}

	protected boolean hasNext()
	{
		return index < size;
	}

	protected SimpleCMSComponentModel next()
	{
		return components.get(index);
	}

	protected void exposeVariables()
	{
		pageContext.setAttribute(var, item, scope);
		pageContext.setAttribute("contentSlot", contentSlot, scope);
		pageContext.setAttribute("elementPos", Integer.valueOf(index), scope);
		pageContext.setAttribute("isFirstElement", Boolean.valueOf(index == 0), scope);
		pageContext.setAttribute("isLastElement", Boolean.valueOf(index == (size - 1)), scope);
		pageContext.setAttribute("numberOfElements", Integer.valueOf(size), scope);
	}

	protected void unexposeVariables()
	{
		pageContext.removeAttribute(var, scope);
		pageContext.removeAttribute("contentSlot", scope);
		pageContext.removeAttribute("elementPos", scope);
		pageContext.removeAttribute("isFirstElement", scope);
		pageContext.removeAttribute("isLastElement", scope);
		pageContext.removeAttribute("numberOfElements", scope);
	}

	@Override
	public int doStartTag() throws JspException
	{
		index = 0;
		prepare();

		if (hasNext())
		{
			item = next();
			exposeVariables();
			index++;
			return EVAL_BODY_INCLUDE;
		}
		return SKIP_BODY;
	}

	@Override
	public int doAfterBody() throws JspException
	{
		if (hasNext())
		{
			item = next();
			exposeVariables();
			index++;
			return EVAL_BODY_AGAIN;
		}
		unexposeVariables();
		return SKIP_BODY;
	}

	public void setContentSlot(final ContentSlotModel contentSlot)
	{
		this.contentSlot = contentSlot;
	}

	public void setUid(final String uid)
	{
		this.uid = uid;
	}

	public void setPosition(final String position)
	{
		this.position = position;
	}

	public void setVar(final String var)
	{
		this.var = var;
	}

	@Override
	public void setBodyContent(final BodyContent bodyContent)
	{
		this.bodyContent = bodyContent;
	}

	public void setScope(final String scope)
	{
		if (StringUtils.isEmpty(scope) || StringUtils.equalsIgnoreCase(scope, "request"))
		{
			this.scope = PageContext.REQUEST_SCOPE;
		}
		else if (StringUtils.equalsIgnoreCase(scope, "page"))
		{
			this.scope = PageContext.PAGE_SCOPE;
		}
	}

}
